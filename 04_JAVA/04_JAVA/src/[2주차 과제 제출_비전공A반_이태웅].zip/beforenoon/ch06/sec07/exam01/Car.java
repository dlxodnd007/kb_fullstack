package beforenoon.ch06.sec07.exam01;

public class Car {
    String model;
    String color;
    int speed;

    Car(String model, String color, int speed) {
        this.model = model;
        this.color = color;
        this.speed = speed;
    }
}
