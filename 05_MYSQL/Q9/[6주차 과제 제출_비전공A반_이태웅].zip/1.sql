use sqldb;

create table tbl1 (
	`a` int primary key,
    `b` int,
    `c` int
);

show index from tbl1;