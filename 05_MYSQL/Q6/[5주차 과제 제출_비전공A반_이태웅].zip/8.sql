# 여덟번째 장
select distinct addr from usertbl order by addr asc; 
