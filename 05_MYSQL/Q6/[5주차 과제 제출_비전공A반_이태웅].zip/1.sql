# 첫번째 장
SHOW databases;

use employees;

show tables;

describe employees;

desc employees;

show columns from employees;
