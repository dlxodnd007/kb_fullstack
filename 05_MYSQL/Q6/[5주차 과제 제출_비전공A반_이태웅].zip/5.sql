# 다섯번째 장
select * from usertbl where height >= 180 and height <= 183;
select * from usertbl where addr='경남' or addr='전북';
select * from usertbl where name like '김%';
