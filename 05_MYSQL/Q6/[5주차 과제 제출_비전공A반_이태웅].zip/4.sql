# 네번째 장
USE sqldb;
select * from usertbl where name = '김경호';
select * from usertbl where birthyear >= 1970 and height >= 182;