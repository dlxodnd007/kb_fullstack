# 두번째 장
select * from titles;
select first_name from employees;
select first_name, last_name, gender from employees;
