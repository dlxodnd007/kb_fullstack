# 일곱번째 장
select * from usertbl order by mDate asc;
select * from usertbl order by mDate desc;
select * from usertbl order by height desc, name desc;
