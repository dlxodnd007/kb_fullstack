# 세번쩨 장
use employees;
select first_name as 이름, gender as 성별, hire_date as '회사 입사일'  from employees;
