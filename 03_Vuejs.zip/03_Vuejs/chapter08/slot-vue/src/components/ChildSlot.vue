<template>
    <div style="border: 1px solid black; padding: 30px">
        <slot></slot>
    </div>
</template>

<script>
export default {
    name: "ChildSlot",
};
</script>

<style lang="scss" scoped></style>
