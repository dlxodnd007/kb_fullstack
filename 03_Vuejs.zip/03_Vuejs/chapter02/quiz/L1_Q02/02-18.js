const d1 = new Date();
let name = "홍길동";
let r1 = `홍길동 님에게 ${d1.toDateString()}`;
console.log(r1);
let product = "갤럭시S7";
let price = 199000;
let str = `${product}의 가격은 ${price} 입니다!`;
console.log(str);
