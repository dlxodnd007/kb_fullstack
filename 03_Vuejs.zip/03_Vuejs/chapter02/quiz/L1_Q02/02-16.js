const name = "홍길동";
const age = 20;
const email = "gdhong@test.com";

const obj = { name, age, email };
// const obj = { name: name, age: age, email: email };
console.log(obj);
