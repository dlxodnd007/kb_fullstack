import { add, multiply } from "./02-19-module";
// 02-19-module 임포트
console.log(add(4));
console.log(multiply(4));
