import getBase, { add } from './14_02-19-module.js';

console.log(add(4));
console.log(getBase());
